<?php
if (!defined("ROOT_PATH"))
{
	header("HTTP/1.1 403 Forbidden");
	exit;
}
class pjListingModel extends pjAppModel
{
	protected $primaryKey = 'id';
	
	protected $table = 'listings';
	
	protected $schema = array(
		array('name' => 'id', 'type' => 'int', 'default' => ':NULL'),
		array('name' => 'type_id', 'type' => 'int', 'default' => ':NULL'),
		array('name' => 'breed_id', 'type' => 'int', 'default' => ':NULL'),
		array('name' => 'feature_age_id', 'type' => 'int', 'default' => ':NULL'),
		array('name' => 'feature_size_id', 'type' => 'int', 'default' => ':NULL'),
		array('name' => 'feature_sex_id', 'type' => 'int', 'default' => ':NULL'),
		array('name' => 'feature_color_id', 'type' => 'int', 'default' => ':NULL'),
			
		array('name' => 'listing_refid', 'type' => 'varchar', 'default' => ':NULL'),
		array('name' => 'listing_price', 'type' => 'decimal', 'default' => ':NULL'),
		array('name' => 'listing_year', 'type' => 'year', 'default' => ':NULL'),
		
		array('name' => 'contact_email', 'type' => 'varchar', 'default' => ':NULL'),
		array('name' => 'contact_phone', 'type' => 'varchar', 'default' => ':NULL'),
		array('name' => 'contact_fax', 'type' => 'varchar', 'default' => ':NULL'),
		array('name' => 'contact_url', 'type' => 'varchar', 'default' => ':NULL'),
		
		array('name' => 'personal_title', 'type' => 'enum', 'default' => 'T'),
		array('name' => 'personal_name', 'type' => 'varchar', 'default' => ':NULL'),
		
		array('name' => 'address_content', 'type' => 'varchar', 'default' => ':NULL'),
		array('name' => 'address_city', 'type' => 'varchar', 'default' => ':NULL'),
		array('name' => 'address_state', 'type' => 'varchar', 'default' => ':NULL'),
		array('name' => 'address_postcode', 'type' => 'varchar', 'default' => ':NULL'),
		array('name' => 'address_country', 'type' => 'int', 'default' => ':NULL'),
		
		array('name' => 'views', 'type' => 'int', 'default' => ':NULL'),
		
		array('name' => 'modified', 'type' => 'datetime', 'default' => ':NULL'),
		array('name' => 'created', 'type' => 'datetime', 'default' => ':NULL'),
			
		array('name' => 'status', 'type' => 'enum', 'default' => 'T')
	);
	
	public $i18n = array('title', 'description', 'meta_title', 'meta_keywords', 'meta_description');
	
	public static function factory($attr=array())
	{
		return new pjListingModel($attr);
	}
}
?>