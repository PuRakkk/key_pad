<ul class="nav nav-tabs pjPl-tabs">
	<?php
	if($_GET['action'] == 'pjActionView')
	{
		?><li><a href="<?php echo $_SERVER['PHP_SELF']; ?>?controller=pjListings&amp;action=pjActionIndex">&laquo; <?php __('front_menu_back')?></a></li><?php
	} 
	?>
	<li<?php echo $_GET['action'] == 'pjActionIndex' ? ' class="active"' : NULL;?>><a href="<?php echo $_SERVER['PHP_SELF']; ?>?controller=pjListings&amp;action=pjActionIndex"><?php __('front_menu_home');?></a></li>
	
	<li<?php echo $_GET['action'] == 'pjActionSearch' ? ' class="active"' : NULL;?>><a href="<?php echo $_SERVER['PHP_SELF']; ?>?controller=pjListings&amp;action=pjActionSearch"><?php __('front_menu_search');?></a></li>
	
	<li class="pull-right">
		<div class="dropdown">
			<?php
			if (isset($tpl['locale_arr']))
			{
				if (count($tpl['locale_arr']) > 1)
				{
					$locale_id = $controller->pjActionGetLocale();
					$selected_lang = '';
					foreach ($tpl['locale_arr'] as $locale)
					{
						if($locale_id == $locale['id'])
						{
							$selected_lang = pjSanitize::html($locale['title']);
						}
					}
					?>
					<button class="btn btn-primary btn-block dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-expanded="true">
						<?php echo $selected_lang;?>
						<span class="caret"></span>
					</button>
					<ul class="dropdown-menu dropdown-menu-right" role="menu" aria-labelledby="dropdownMenu1">
						<?php
						foreach ($tpl['locale_arr'] as $k => $locale)
						{
							?>
							<li>
								<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo $_SERVER['SCRIPT_NAME']; ?>?controller=pjListings&amp;action=pjActionSetLocale&amp;locale=<?php echo $locale['id']; ?><?php echo isset($_GET['iframe']) ? '&amp;iframe' : NULL; ?>"><?php echo pjSanitize::html($locale['title']); ?></a></li>
							</li>
							<?php
						}
						?>
					</ul>
					<?php
				}
			} 
			?>
		</div>
	</li>
</ul>
