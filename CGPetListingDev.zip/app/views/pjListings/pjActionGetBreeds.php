<label class="control-label"><?php __('front_breed');?>:</label>
						
<select name="breed_id" class="form-control">
	<option value="">-- <?php __('front_all');?> --</option>
	<?php
	foreach ($tpl['breed_arr'] as $k => $v)
	{
		?><option value="<?php echo $v['id']; ?>"><?php echo pjSanitize::html($v['name']); ?></option><?php
	}
	?>
</select>