<?php
mt_srand();
$index = mt_rand(1, 9999);
?>
<div id="pjWrapper">
	<div class="container-fluid">
		<?php
		include_once PJ_VIEWS_PATH . 'pjListings/elements/header.php';
		?>
		<div class="pjPl-animal-form">
			<form method="get">
				<input type="hidden" value="pjListings" name="controller">
				<input type="hidden" value="pjActionIndex" name="action">
				<input type="hidden" value="1" name="listing_search">
				<div class="row">
					<div class="col-sm-6">
						<div class="form-group">
							<label class="control-label"><?php __('front_type');?>:</label>
						
							<select name="type_id" class="form-control pjPlTypeSelector">
								<option value="">-- <?php __('front_all');?> --</option>
								<?php
								foreach($tpl['type_arr'] as $v)
								{ 
									?><option value="<?php echo $v['id'];?>"><?php echo pjSanitize::html($v['name']);?></option><?php
								}
								?>
							</select>
						</div><!-- /.form-group -->
						<div id="pjPlBreed_<?php echo $index;?>" class="form-group">
							<label class="control-label"><?php __('front_breed');?>:</label>
						
							<select name="breed_id" class="form-control">
								<option value="">-- <?php __('front_all');?> --</option>
							</select>
						</div><!-- /.form-group -->
						<div class="form-group">
							<label class="control-label"><?php __('front_reference_id');?>:</label>
					
							<input type="text" name="listing_refid" class="form-control">
						</div><!-- /.form-group -->
						<div class="form-group">
							<label class="control-label"><?php __('front_year_of_birth');?>:</label>
					
							<div class="row">
								<div class="col-sm-5">
									<select name="year_from" class="form-control">
										<option value="">-- <?php __('front_all');?> --</option>
										<?php
										for($i = date('Y'); $i >= date('Y') - 50; $i-- )
										{
											?><option value="<?php echo $i; ?>"><?php echo $i; ?></option><?php
										} 
										?>
									</select>
								</div><!-- /.col-sm-6 -->
		
								<div class="col-sm-2">
									<p class="text-center"><?php __('front_to');?></p>
								</div><!-- /.col-sm-2 -->
													
								<div class="col-sm-5">
									<select name="year_to" class="form-control">
										<option value="">-- <?php __('front_all');?> --</option>
										<?php
										for($i = date('Y'); $i >= date('Y') - 50; $i-- )
										{
											?><option value="<?php echo $i; ?>"><?php echo $i; ?></option><?php
										} 
										?>
									</select>
								</div><!-- /.col-sm-6 -->
							</div><!-- /.row -->
						</div><!-- /.form-group -->
					</div><!-- /.col-sm-6 -->
		
					<div class="col-sm-6">
						<?php
						foreach(__('feature_types', true) as $k => $v)
						{
							$feature_arr = $tpl['feature_arr'][$k];
							if(isset($feature_arr) && count($feature_arr))
							{
								?>
								<div class="form-group">
									<label class="control-label"><?php echo $v; ?></label>
								
									<select name="feature_<?php echo $k;?>_id" class="form-control">
										<option value="">-- <?php __('front_all');?> --</option>
										<?php
										foreach($feature_arr as $feature)
										{
											?>
											<option value="<?php echo $feature['id'];?>"><?php echo $feature['name'];?></option>
											<?php
										}	 
										?>
									</select>
								</div><!-- /.form-group -->
								<?php
							}
						} 
						?>
					</div><!-- /.col-sm-6 -->
				</div>
		
				<button type="submit" class="btn btn-primary"><?php __('front_btn_search');?></button>
			</form>
		</div><!-- /.pjPl-animal-form -->
		
	</div><!-- /.container -->
</div><!-- /#pjWrapper -->

<?php include_once PJ_VIEWS_PATH . 'pjListings/elements/loadjs.php';?>