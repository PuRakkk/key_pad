<?php
mt_srand();
$index = mt_rand(1, 9999);
?>
<div id="pjWrapper">
	<div class="container-fluid">
		<?php
		include_once PJ_VIEWS_PATH . 'pjListings/elements/header.php';
		?>
		<div class="pjPl-animal">
			<?php 
			if(isset($tpl['arr']))
			{
				if(!empty($tpl['arr']))
				{
					if($tpl['arr']['status'] == 'T')
					{
						?>
						<h1><?php echo pjSanitize::html($tpl['arr']['title']);?></h1>
						
						<div class="row">
							<?php
							if (count($tpl['gallery_arr']) > 0)
							{ 
								?>
								<div class="col-md-7">
									<div class="pjPl-animal-image">
										<a rel="lytebox[allphotos]" href="<?php echo PJ_INSTALL_URL . $tpl['gallery_arr'][0]['large_path']; ?>">
											<img src="<?php echo PJ_INSTALL_URL . $tpl['gallery_arr'][0]['medium_path'];?>" alt="" class="img-responsive" />
										</a>
								    </div><!-- /.pjPl-animal-image -->
			
									<div class="row pjPl-animal-thumbs">
										<?php
										foreach($tpl['gallery_arr'] as $thumb)
										{
											?>
											<div class="col-sm-4 col-xs-6">
										    	<a rel="lytebox[allphotos]" href="<?php echo PJ_INSTALL_URL . $thumb['large_path']; ?>">
										    		<img src="<?php echo PJ_INSTALL_URL . $thumb['small_path'];?>" class="img-responsive" alt="">
											    </a>
										    </div><!-- /.col-md-3 -->
											<?php
										} 
										?>
									</div><!-- /.row -->
								</div><!-- /.col-md-7 -->
								<?php
							} 
							?>
							<div class="col-md-5">
								<ul class="list-group">
									<li class="list-group-item"><span class="pull-left"><?php __('front_type');?></span> <strong class="pull-right"><?php echo pjSanitize::html($tpl['arr']['type']);?></strong></li>
									<li class="list-group-item"><span class="pull-left"><?php __('front_breed');?></span> <strong class="pull-right"><?php echo pjSanitize::html($tpl['arr']['breed']);?></strong></li>
									<?php
									if(!empty($tpl['arr']['listing_price']))
									{ 
										?>
										<li class="list-group-item"><span class="pull-left"><?php __('front_price');?></span> <strong class="pull-right"><?php echo pjUtil::formatCurrencySign($tpl['arr']['listing_price'], $tpl['option_arr']['o_currency']);?></strong></li>
										<?php
									} 
									if(!empty($tpl['arr']['listing_price']))
									{ 
										?>
										<li class="list-group-item"><span class="pull-left"><?php __('front_year_of_birth');?></span> <strong class="pull-right"><?php echo $tpl['arr']['listing_year'];?></strong></li>
										<?php
									}
									foreach(__('feature_types', true) as $k => $v)
									{
										if(!empty($tpl['arr'][$k]))
										{
											?><li class="list-group-item"><span class="pull-left"><?php echo $v;?></span> <strong class="pull-right"><?php echo $tpl['arr'][$k];?></strong></li><?php
										}
									} 
									?>
									<li class="list-group-item"><span class="pull-left"><?php __('front_reference_id');?></span> <strong class="pull-right"><?php echo pjSanitize::html($tpl['arr']['listing_refid']);?></strong></li>
								</ul>
							</div><!-- /.col-md-6 -->
						</div><!-- .row -->
						
						<?php
						if(!empty($tpl['listing_extra_arr']))
						{ 
							?>
							<div class="panel panel-default">
								<div class="panel-heading"><?php __('front_feature_set');?> </div><!-- /.panel-heading -->
			
								<div class="panel-body">
									<div class="row">
										<?php
										foreach($tpl['extra_arr'] as $v)
										{
											if(in_array($v['id'], $tpl['listing_extra_arr']))
											{
												?>
												<div class="col-sm-3">
													<p><?php echo pjSanitize::html($v['name']);?></p>
												</div><!-- /.col-sm-3 -->
												<?php
											}
										} 
										?>
									</div><!-- /.row -->
								</div><!-- /.panel-body -->
							</div><!-- /.panel -->	
							<?php
						}
						?>
						<div class="panel panel-default">
							<div class="panel-heading"><?php __('front_pet_description');?></div>
						
							<div class="panel-body">
								<?php echo stripslashes($tpl['arr']['description']);?>
							</div>
						</div><!-- /. panel -->
						
						<?php
						ob_start();
						
						$name_arr = array();
						if($tpl['arr']['personal_title'])
						{
							$personal_titles = __('personal_titles', true);
							$name_arr[] = $personal_titles[$tpl['arr']['personal_title']];
						}
						if($tpl['arr']['personal_name'])
						{
							$name_arr[] = $tpl['arr']['personal_name'];
						}
						if(!empty($name_arr))
						{
							?>
							<div class="row">
								<div class="col-sm-6 col-xs-5">
									<strong><?php __('front_name');?></strong>
								</div>
								
								<div class="col-sm-6 col-xs-7">
									<p><?php echo implode(" ", $name_arr);?></p>
								</div>
							</div><!-- /.row -->
							<?php
						}
						if(!empty($tpl['arr']['contact_email']))
						{
						    $ascii_email = pjUtil::toAscii($tpl['arr']['contact_email']);
							?>
							<div class="row">
								<div class="col-sm-6 col-xs-5">
									<strong><?php __('front_email');?></strong>
								</div>
								
								<div class="col-sm-6 col-xs-7">
									<p><a href="mailto:<?php echo $ascii_email; ?>"><?php echo $ascii_email; ?></a></p>
								</div>
							</div><!-- /.row -->
							<?php
						}
						if(!empty($tpl['arr']['contact_phone']))
						{
							?>
							<div class="row">
								<div class="col-sm-6 col-xs-5">
									<strong><?php __('front_phone');?></strong>
								</div>
								
								<div class="col-sm-6 col-xs-7">
									<p><?php echo $tpl['arr']['contact_phone']; ?></p>
								</div>
							</div><!-- /.row -->
							<?php
						}
						if(!empty($tpl['arr']['contact_fax']))
						{
							?>
							<div class="row">
								<div class="col-sm-6 col-xs-5">
									<strong><?php __('front_fax');?></strong>
								</div>
								
								<div class="col-sm-6 col-xs-7">
									<p><?php echo $tpl['arr']['contact_fax']; ?></p>
								</div>
							</div><!-- /.row -->
							<?php
						}
						if(!empty($tpl['arr']['contact_url']))
						{
						    $ascii_url = pjUtil::toAscii($tpl['arr']['contact_url']);
							?>
							<div class="row">
								<div class="col-sm-6 col-xs-5">
									<strong><?php __('front_website');?></strong>
								</div>
								
								<div class="col-sm-6 col-xs-7">
									<p><a href="<?php echo $ascii_url; ?>" target="_blank"><?php echo $ascii_url; ?></a></p>
								</div>
							</div><!-- /.row -->
							<?php
						}
						if(!empty($tpl['arr']['address_content']))
						{
							?>
							<div class="row">
								<div class="col-sm-6 col-xs-5">
									<strong><?php __('front_address');?></strong>
								</div>
								
								<div class="col-sm-6 col-xs-7">
									<p><?php echo $tpl['arr']['address_content']; ?></p>
								</div>
							</div><!-- /.row -->
							<?php
						}
						if(!empty($tpl['arr']['address_city']))
						{
							?>
							<div class="row">
								<div class="col-sm-6 col-xs-5">
									<strong><?php __('front_city');?></strong>
								</div>
								
								<div class="col-sm-6 col-xs-7">
									<p><?php echo $tpl['arr']['address_city']; ?></p>
								</div>
							</div><!-- /.row -->
							<?php
						}
						if(!empty($tpl['arr']['address_state']))
						{
							?>
							<div class="row">
								<div class="col-sm-6 col-xs-5">
									<strong><?php __('front_state');?></strong>
								</div>
								
								<div class="col-sm-6 col-xs-7">
									<p><?php echo $tpl['arr']['address_state']; ?></p>
								</div>
							</div><!-- /.row -->
							<?php
						}
						if(!empty($tpl['arr']['address_postcode']))
						{
							?>
							<div class="row">
								<div class="col-sm-6 col-xs-5">
									<strong><?php __('front_postcode');?></strong>
								</div>
								
								<div class="col-sm-6 col-xs-7">
									<p><?php echo $tpl['arr']['address_postcode']; ?></p>
								</div>
							</div><!-- /.row -->
							<?php
						}
						if(!empty($tpl['arr']['country_title']))
						{
							?>
							<div class="row">
								<div class="col-sm-6 col-xs-5">
									<strong><?php __('front_country');?></strong>
								</div>
								
								<div class="col-sm-6 col-xs-7">
									<p><?php echo $tpl['arr']['country_title']; ?></p>
								</div>
							</div><!-- /.row -->
							<?php
						}
						$ob_contact = ob_get_contents();
						ob_end_clean();
						if (!empty($ob_contact))
						{
							?>
							
							<div class="panel panel-default pjPl-contact-details">
								<div class="panel-heading"><?php __('front_contact_details');?></div>
							
								<div class="panel-body">
									<?php
									echo $ob_contact; 
									?>
								</div>
							</div><!-- /.panel panel-default -->
							<?php 
						}
					}else{
						__('front_pet_disabled');
					}
				}else{
					__('front_pet_not_exist');
				}
			}else{
				__('front_pet_not_exist');
			}
			?>
		</div><!-- /.pjPl-animal -->
	</div><!-- /.container -->
</div><!-- /#pjWrapper -->

<?php include_once PJ_VIEWS_PATH . 'pjListings/elements/loadjs.php';?>