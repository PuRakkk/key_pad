<?php
$type = '<select name="type_id" id="type_id" class="pj-form-field w200 required" data-msg-required="'.__('lblFieldRequired', true).'" data-msg-remote="'.__('lblPetBreedDuplicated', true).'">';
$type .= sprintf('<option value="">-- %s --</option>', __('lblChoose', true));
foreach ($tpl['type_arr'] as $v)
{
	$type .= sprintf('<option value="%u">%s</option>', $v['id'], stripslashes($v['name']));
}
$type .= '</select>';
pjAppController::jsonResponse(compact('type'));
?>