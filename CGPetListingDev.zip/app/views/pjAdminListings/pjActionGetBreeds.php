<select name="breed_id" id="breed_id" class="pj-form-field w200 required" data-msg-required="<?php __('lblFieldRequired');?>">
	<option value="">-- <?php __('lblChoose'); ?>--</option>
	<?php
	foreach ($tpl['breed_arr'] as $k => $v)
	{
		?><option value="<?php echo $v['id']; ?>"><?php echo pjSanitize::html($v['name']); ?></option><?php
	}
	?>
</select>